import turtle, pandas as pd

screen = turtle.Screen()
screen.title("U.S. State Game")
image = "download.gif"
screen.addshape(image)
turtle.shape(image)

guess_state = []
while len(guess_state) < 50:
    answer_state = screen.textinput(title=f"{len(guess_state)}/50 States Correct",
                                    prompt="What's another state's name?").title()
    data = pd.read_csv("50_states.csv")
    state_list = data.state.to_list()
    if answer_state == "Exit":
        missing_states = []
        for state in state_list:
            if state not in guess_state:
                missing_states.append(state)
        new_data = pd.DataFrame(missing_states)
        new_data.to_csv("states_to_learn.csv")
        break
    if answer_state in state_list:
        guess_state.append(answer_state)
        state = turtle.Turtle()
        state.hideturtle()
        state.penup()
        state_data = data[data["state"] == answer_state]
        state.goto(int(state_data.x), int(state_data.y))
        state.write(answer_state)