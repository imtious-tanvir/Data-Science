#read file
with open("my_file.txt") as file:
    content = file.read()
    print(content)

#write file
with open("my_file.txt", "a") as file:
    content = file.write("\nNew text.")
    print(content)
