import pandas as pd

data = pd.read_csv("nato_phonetic_alphabet.csv")

data_to_dict = {row.letter: row.code for (index, row) in data.iterrows()}

given_word = input("Enter a word: ").upper()
list = [data_to_dict[letter] for letter in given_word]

print(list)