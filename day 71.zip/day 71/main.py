import pandas as pd
df = pd.read_csv("salaries_by_college_major.csv")


#print_head_value
#print(df.head())


#print row and column of the data frame
#print(df.shape)


#show columns
#print(df.columns())


#look for not a number
df.isna()

#print last value
df.tail()


#drop last value
clean_df = df.dropna()
last_column = clean_df.tail()
#print(last_column)

#print one column
catch_Starting_Median_Salary_column = clean_df['Starting Median Salary']


#print maxium value
print(catch_Starting_Median_Salary_column.max())


#print which id is maximum
catch_id_which_is_highest = catch_Starting_Median_Salary_column.idxmax()
print(catch_id_which_is_highest)


#print which department and do
catch_Undergraduate_Major_column = clean_df['Undergraduate Major']
location_which_major_is_highest = catch_Undergraduate_Major_column.loc[catch_id_which_is_highest]
print(location_which_major_is_highest)


#lowest risk major and insert one column
another_col = clean_df['Mid-Career 90th Percentile Salary'].subtract(clean_df['Mid-Career 10th Percentile Salary'])
clean_df.insert(1, 'Spread', another_col)
print(clean_df.head())


#print sort top 5 value and merge two column
low_risk = clean_df.sort_values('Spread')
top_5 = low_risk[['Undergraduate Major', 'Spread']].head()
print(top_5)


#groupby means how much group in the group column
print(clean_df.groupby('Group').count())